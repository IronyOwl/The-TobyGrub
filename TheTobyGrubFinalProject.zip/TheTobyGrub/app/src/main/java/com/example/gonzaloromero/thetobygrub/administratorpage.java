package com.example.gonzaloromero.thetobygrub;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class administratorpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administratorpage);
    }
}
